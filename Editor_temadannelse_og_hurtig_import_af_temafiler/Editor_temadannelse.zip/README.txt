Titel: Materiale ifm. pr�sentation den 27-11-2020 ved SAS Fans Programmering Netv�rksm�de.
Forfatter: Andreas Kracht Frandsen.

Filer-----------------
AKF_Dark.reg - Scheme til .sas filtyper i SAS DM/Foundation v9.4.

AKF_EG_Dark.reg - Scheme til .sas filtyper i SAS Enterprise Guide.

AKF_EG_Log_Dark.reg - Scheme til .log filtyper i SAS Enterprise Guide v8.2.

SAS_Fans_Editor_Temadannelse_og_hurtig_import_af_temafiler.pdf - Slides fra pr�sentation.

Eksempel_med_ekstra_tip.sas - Kodestump benyttet ifm. pr�sentation. Indeholder kommentar vedr. ekstra tip til makroprogrammer/funktioner.

Info-----------------
Registreringsfilerne kan importeres til SAS via Registreringseditoren (Filer -> Importer), givet at versionen af SAS stemmer overens med mit setup.
Pr�v derfor f�rst at lave dit eget 'Scheme' i en SAS session inden du importer mine filer. Tjek herefter at du kan finde dit 'Scheme' i Registreringseditoren.
Er du usikker p� noget s� lav en backup af registreringsdatabasen.